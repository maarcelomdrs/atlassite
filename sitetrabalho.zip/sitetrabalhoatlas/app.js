document.addEventListener("DOMContentLoaded", () => {

  /* -------- Dropdowns do topo (Setores / SAC) -------- */
  const dropdowns = document.querySelectorAll(".dropdown");

  dropdowns.forEach(drop => {
    const btn = drop.querySelector(".dropbtn");

    // Hover (desktop)
    drop.addEventListener("mouseenter", () => {
      drop.classList.add("show");
      if (btn) btn.setAttribute("aria-expanded", "true");
    });
    drop.addEventListener("mouseleave", () => {
      drop.classList.remove("show");
      if (btn) btn.setAttribute("aria-expanded", "false");
    });

    // Clique para abrir/fechar (mobile / acessibilidade)
    if (btn) {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const isOpen = drop.classList.contains("show");
        // fechar outros
        dropdowns.forEach(d => {
          d.classList.remove("show");
          const b = d.querySelector(".dropbtn"); if (b) b.setAttribute("aria-expanded","false");
        });
        if (!isOpen) {
          drop.classList.add("show");
          btn.setAttribute("aria-expanded", "true");
        } else {
          drop.classList.remove("show");
          btn.setAttribute("aria-expanded", "false");
        }
      });

      // teclado
      btn.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          btn.click();
        } else if (e.key === "Escape") {
          drop.classList.remove("show");
          btn.setAttribute("aria-expanded", "false");
        }
      });
    }
  });

  // clicar fora fecha tudo
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".dropdown")) {
      dropdowns.forEach(d => {
        d.classList.remove("show");
        const b = d.querySelector(".dropbtn"); if (b) b.setAttribute("aria-expanded","false");
      });
    }
  });

  // ESC geral fecha dropdowns
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      dropdowns.forEach(d => {
        d.classList.remove("show");
        const b = d.querySelector(".dropbtn"); if (b) b.setAttribute("aria-expanded","false");
      });
    }
  });


  /* -------- Cards (abrir/fechar conteúdo interno) -------- */
  const cards = document.querySelectorAll(".card");

  cards.forEach(card => {
    const content = card.querySelector(".content");

    // Hover já está coberto pelo CSS; aqui adicionamos classes para clique/keyboard
    card.addEventListener("click", (e) => {
      // evita disparo ao clicar dentro de links/inputs caso tenha
      if (e.target.tagName.toLowerCase() === "a" || e.target.closest("a")) return;

      const isOpen = card.classList.contains("show");
      // fechar todos se for comportamento de accordéon (opcional). aqui permitimos múltiplos abertos:
      // cards.forEach(c => c.classList.remove("show"));

      if (isOpen) {
        card.classList.remove("show");
        if (content) {
          content.style.maxHeight = null;
          content.style.paddingTop = "";
        }
      } else {
        card.classList.add("show");
        if (content) {
          content.style.maxHeight = content.scrollHeight + "px";
          content.style.paddingTop = "6px";
        }
      }
    });

    // Acessibilidade: abrir/fechar com Enter / Space quando o card estiver em foco
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        card.click();
      } else if (e.key === "Escape") {
        card.classList.remove("show");
        if (content) {
          content.style.maxHeight = null;
          content.style.paddingTop = "";
        }
      }
    });

    // Ajusta altura ao redimensionar (se estiver aberto)
    window.addEventListener("resize", () => {
      if (card.classList.contains("show") && content) {
        content.style.maxHeight = content.scrollHeight + "px";
      }
    });
  });
});